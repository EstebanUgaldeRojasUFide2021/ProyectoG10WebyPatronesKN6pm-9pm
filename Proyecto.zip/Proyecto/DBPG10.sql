drop schema proyecto ;
drop user admin;

CREATE SCHEMA proyecto;
create user 'admin'@'%' identified by 'admin';
grant all privileges on proyecto.* to 'admin'@'%';
flush privileges;

CREATE TABLE proyecto.usuario(
id_usuario INT NOT NULL AUTO_INCREMENT,
nombre  VARCHAR(30) NOT NULL,
apellidos  VARCHAR(30) NOT NULL,
correo  VARCHAR(30) NOT NULL,
telefono  VARCHAR(30) NOT NULL,
fecha_de_nacimiento VARCHAR(30) NOT NULL,
pais  VARCHAR(30) NOT NULL,
PRIMARY KEY (`id_usuario`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

CREATE TABLE proyecto.temporada(
id_temporada INT NOT NULL AUTO_INCREMENT,
nombre_temporada VARCHAR(30) NOT NULL,
activo bool,
PRIMARY KEY (`id_temporada`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

CREATE TABLE proyecto.producto(
codigo_producto INT NOT NULL AUTO_INCREMENT,
/*id_temporada INT NOT NULL,*/
nombre_producto VARCHAR(30) NOT NULL,
descripcion VARCHAR(50) NOT NULL,
marca_producto VARCHAR(30) NOT NULL,
color_producto VARCHAR(30) NOT NULL,
cantidad_producto INT NOT NULL,
precio_producto INT NOT NULL,
activo bool,
PRIMARY KEY (`codigo_producto`)
/*foreign key fk_id_temporada (id_temporada) references temporada(id_temporada)*/
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

CREATE TABLE proyecto.hombres(
codigo_hombre INT NOT NULL AUTO_INCREMENT,
nombre_hombre VARCHAR(30) NOT NULL,
descripcion VARCHAR(50) NOT NULL,
marca_hombre VARCHAR(30) NOT NULL,
color_hombre VARCHAR(30) NOT NULL,
cantidad_hombre INT NOT NULL,
precio_hombre INT NOT NULL,
activo bool,
ruta_imagen varchar(200),
PRIMARY KEY (`codigo_hombre`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

CREATE TABLE proyecto.mujeres(
codigo_mujer INT NOT NULL AUTO_INCREMENT,
nombre_mujer VARCHAR(30) NOT NULL,
descripcion VARCHAR(50) NOT NULL,
marca_mujer VARCHAR(30) NOT NULL,
color_mujer VARCHAR(30) NOT NULL,
cantidad_mujer INT NOT NULL,
precio_mujer INT NOT NULL,
activo bool,
ruta_imagen varchar(200),
PRIMARY KEY (`codigo_mujer`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

CREATE TABLE proyecto.infantiles(
codigo_infantil INT NOT NULL AUTO_INCREMENT,
nombre_infantil VARCHAR(30) NOT NULL,
descripcion VARCHAR(50) NOT NULL,
marca_infantil VARCHAR(30) NOT NULL,
color_infantil VARCHAR(30) NOT NULL,
cantidad_infantil INT NOT NULL,
precio_infantil INT NOT NULL,
activo bool,
ruta_imagen varchar(200),
PRIMARY KEY (`codigo_infantil`)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

create table proyecto.autenticar(  
     id_auth INT NOT NULL AUTO_INCREMENT,  
     username varchar(40) not null,  
     password varchar(250) not null,  
     correo varchar(50) not null,  
     PRIMARY KEY (id_auth)  
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

create table proyecto.rol (  
      id_rol INT NOT NULL AUTO_INCREMENT,  
      nombre varchar(25), 
      id_auth int not null,  
      PRIMARY KEY (id_rol),  
      foreign key fk_rol_auth (id_auth) references autenticar(id_auth)  
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_eo_0900_ai_ci;

insert into proyecto.autenticar values 
(1,'Esteban','$2a$10$GlRDxdPjteVgSzjIg5UFAOSw17cjeTY8mGDRMUZR047IpXSnQFyZC','estebanugalde@gmail.com'),
(2,'Andres','$2a$10$ddEEjB9wcdm8.gQI1XLYQO5d.7XSkT4dCYDEY8fi4E6ZS0hyI1XTG','andresmorales@gmail.com'),
(3,'Gaspar','$2a$10$Yb09LN371hT4yxj8.SV12.FtOYYnyIOEqgdnp37AgjDMqZe9T93lK','gasparovares@gmail.com');

insert into proyecto.rol values 
(1,'ROLE_ADMIN',1),
(2,'ROLE_EMPLEADO',1),
(3,'ROLE_CLIENTE',1);

INSERT INTO proyecto.usuario (id_usuario, nombre, apellidos, correo, telefono, fecha_de_nacimiento, pais) VALUES
(1, 'Juan', 'Castro Mora',    'jcastro@gmail.com',    '4556-8978', '11/03/2001', 'Costa Rica'),
(2, 'Ana',  'Contreras Mora', 'acontreras@gmail.com', '5456-8789', '12/04/2002', 'Francia'),
(3, 'Luis', 'Mena Loria',     'lmena@gmail.com', '7898-8936', '13/05/2003', 'Brasil');

INSERT INTO proyecto.hombres (codigo_hombre,nombre_hombre, descripcion, marca_hombre, color_hombre, cantidad_hombre, precio_hombre,activo) VALUES
('1',/*'1'*/'Pantalon','Vaqueros hechos para trabajadores','Levis','Negro',26, 1800, true),
('2',/*'1'*/'Pantaloneta','Pantaloneta deportiva','Nike','Blanca',20, 2500, true),
('3',/*'1'*/'Skull Heart','T-shirt hecha de seda','Adidas','Negro',56, 3500, true),
('4',/*'1'*/'Camisa Formal', 'Camisa formal para hombre','Tommy Hilfiger','Negro',30, 7500, false),
('5',/*'1'*/'Gorra','Gorra hecha con tejido crochet','gap','Rojo',40, 4500, true),
('6',/*'2'*/'T-Shirt','T-shirt hecha de algodon','New Balance','Blanco',50, 5500,  true),
('7',/*'3'*/'Sueter','Sueter hecha con tejido crochet','Old Navy','Naranja',60, 6500,  true),
('8',/*'4'*/'Corbata','Corbata fina hecha de algodón', 'Oscar de la Tienda','negro',30, 7500,   false);

INSERT INTO proyecto.mujeres (codigo_mujer,nombre_mujer, descripcion, marca_mujer, color_mujer, cantidad_mujer, precio_mujer,activo) VALUES
('1',/*'1'*/'Vestido','Vestido Fino de Gala','Versace','Negro',45, 1800, true),
('2',/*'1'*/'Jeans','Jeans Slim Fit ','Guesss','Blanco',23, 10500, true),
('3',/*'1'*/'Blusa','Blusa hecha de seda','Fendi','Negro',563, 6500, true),
('4',/*'1'*/'Top', 'Top deportivo para ejercicio','New Balance','Negro',30, 7500, false),
('5',/*'1'*/'Brasier','Brasier de realce suave','Diane','Negro',40, 1500, true),
('6',/*'2'*/'Blusa','Blusa hecha de algodon','Fendi','Blanco',50, 8500,  true),
('7',/*'3'*/'Sueter','Sueter hecha con tejido crochet','Old Navy','Naranja',60, 6500,  true),
('8',/*'4'*/'Botas','Botas hechas de cuero', 'Guess','Amarillo',30, 7500,   false);

INSERT INTO proyecto.infantiles (codigo_infantil,nombre_infantil, descripcion, marca_infantil, color_infantil, cantidad_infantil, precio_infantil,activo) VALUES
('1',/*'1'*/'Camisa','Camisa para bebe','kidswantstoplay','rojo',45, 1800, true),
('2',/*'1'*/'Pijama','Pijama de una pieza para bebe','Guesss','Blanco',233, 500, true),
('3',/*'1'*/'Pijama Navideña','Perfecta para las festividades','Babyinc','rojo',545, 1500, true),
('4',/*'1'*/'Vestido', 'Vestido sin mangas para niña','Picaros','rosado',198, 2500, false),
('5',/*'1'*/'T-shirt Monsters Inc','Para los pequeños fanaticos de disney pixar','Disney','Azul',560, 1500, true),
('6',/*'2'*/'Mameluco','Mameluco con rayas de tiburón','KidsonPlay','Azul',580, 3500,  true),
('7',/*'3'*/'T-shirt Cars','T-shirt de las películas de cars', 'Pixar','Rojo',300, 5500,true),
('8',/*'4'*/'Mameluco','Mameluco hecho de algodón','Old Navy','Naranja',60, 6500, false);

INSERT INTO proyecto.temporada (id_temporada,nombre_temporada,activo) VALUES
('1','Invierno', true),
('2','Verano',  true),
('3','Otoño',true),
('4','Primavera', false);

INSERT INTO proyecto.producto (codigo_producto, /*id_temporada*/ nombre_producto, descripcion, marca_producto, color_producto, cantidad_producto, precio_producto,activo) VALUES
/*codigo_infantil,nombre_infantil, descripcion, marca_infantil, color_infantil, cantidad_infantil, precio_infantil,activo,
codigo_mujer,nombre_mujer, descripcion, marca_mujer, color_mujer, cantidad_mujer, precio_mujer,activo,
codigo_hombre,nombre_hombre, descripcion, marca_hombre, color_hombre, cantidad_hombre, precio_hombre,activo*/
('1',/*'1'*/'Sueter','Sueter hecha de algodon','Gucci','Rojo',10, 1500, true),
('2',/*'1'*/'Pantaloneta','Pantaloneta veraniega','Nike','Azul',20, 2500, true),
('3',/*'1'*/'Skull T-Shirt','T-shirt hecha de seda','Happy Hill','Negro',30, 3500, true),
('4',/*'1'*/'Capa', 'Capa impermeable','Tommy Hilfiger','Verde',30, 3500, false),
('5',/*'1'*/'Gorro','Gorro hecho con tejido crochet','Gap','Morado',40, 4500, true),
('6',/*'2'*/'T-Shirt','T-shirt hecha de algodon','Adidas','Cafe',50, 5500,  true),
('7',/*'3'*/'Bufanda','Bufanda hecha con tejido crochet','Old Navy','Naranjo',60, 6500,  true),
('8',/*'4'*/'Botas','Botas hechas de cuero', 'Guess','Amarillo',30, 7500,   false),
('9',/*'1'*/'Pantalon','Vaqueros hechos para trabajadores','Levis','Negro',26, 1800, true),
('10',/*'1'*/'Pantaloneta','Pantaloneta deportiva hecha de poliester','Nike','Blanca',20, 2500, true),
('11',/*'1'*/'Skull Heart','T-shirt hecha de seda','Adidas','Negro',56, 3500, true),
('12',/*'1'*/'Camisa Formal', 'Camisa formal para hombre','Tommy Hilfiger','Negro',30, 7500, false),
('13',/*'1'*/'Gorra','Gorra hecha con tejido crochet','gap','Rojo',40, 4500, true),
('14',/*'2'*/'T-Shirt','T-shirt hecha de algodon','New Balance','Blanco',50, 5500,  true),
('15',/*'3'*/'Sueter','Sueter hecha con tejido crochet','Old Navy','Naranja',60, 6500,  true),
('16',/*'4'*/'Corbata','Corbata fina hecha de algodón', 'Oscar de la Tienda','negro',30, 7500,   false),
('17',/*'1'*/'Vestido','Vestido Fino de Gala','Versace','Negro',45, 1800, true),
('18',/*'1'*/'Jeans','Jeans Slim Fit ','Guesss','Blanco',23, 10500, true),
('19',/*'1'*/'Blusa','Blusa hecha de seda','Fendi','Negro',563, 6500, true),
('20',/*'1'*/'Top', 'Top deportivo para ejercicio','New Balance','Negro',30, 7500, false),
('21',/*'1'*/'Brasier','Brasier de realce suave','Diane','Negro',40, 1500, true),
('22',/*'2'*/'Blusa','Blusa hecha de algodon','Fendi','Blanco',50, 8500,  true),
('23',/*'3'*/'Sueter','Sueter hecha con tejido crochet','Old Navy','Naranja',60, 6500,  true),
('24',/*'4'*/'Botas','Botas hechas de cuero', 'Guess','Amarillo',30, 7500,   false),
('25',/*'1'*/'Camisa','Camisa para bebe','kidswantstoplay','rojo',45, 1800, true),
('26',/*'1'*/'Pijama','Pijama de una pieza para bebe','Guesss','Blanco',233, 500, true),
('27',/*'1'*/'Pijama Navideña','Perfecta para las festividades','Babyinc','rojo',545, 1500, true),
('28',/*'1'*/'Vestido', 'Vestido sin mangas para niña','Picaros','rosado',198, 2500, false),
('29',/*'1'*/'T-shirt Monsters Inc','Para los pequeños fanaticos de disney pixar','Disney','Azul',560, 1500, true),
('30',/*'2'*/'Mameluco','Mameluco con rayas de tiburón','KidsonPlay','Azul',580, 3500,  true),
('31',/*'3'*/'T-shirt Cars','T-shirt de las películas de cars', 'Pixar','Rojo',300, 5500,true),
('32',/*'4'*/'Mameluco','Mameluco hecho de algodón','Old Navy','Naranja',60, 6500, false); 

