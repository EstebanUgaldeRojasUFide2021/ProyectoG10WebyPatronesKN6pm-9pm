
package com.tiendapg10copia;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Encriptar {
    public static void main(String[] args){
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        var claveEsteban = encoder.encode("489");
        var claveAndres = encoder.encode("500");
        var claveGaspar = encoder.encode("678");
        System.out.println(claveEsteban);
        System.out.println(claveAndres);
        System.out.println(claveGaspar);
                
    }
    
}
