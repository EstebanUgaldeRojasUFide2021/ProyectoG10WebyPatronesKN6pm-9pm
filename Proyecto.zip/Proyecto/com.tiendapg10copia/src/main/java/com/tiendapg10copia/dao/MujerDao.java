
package com.tiendapg10copia.dao;


import com.tiendapg10copia.domain.Mujer;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Andres
 */
public interface MujerDao extends JpaRepository<Mujer,Long>{} 
    