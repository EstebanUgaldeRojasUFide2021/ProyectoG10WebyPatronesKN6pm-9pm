package com.tiendapg10copia.controller;

import com.tiendapg10copia.domain.Hombre;
import com.tiendapg10copia.service.HombreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author Andres
 */

@Controller
@Slf4j
public class HombreController {
    
    @Autowired
    private HombreService hombreService;
    
    @GetMapping("/hombre/listado")
    public String listado(Model model) 
    {
        var hombres=hombreService.getHombres(false);
        
        model.addAttribute("hombres",hombres);
        return "/hombre/listado";
    }
    
    @GetMapping("/hombre/nuevo")
    public String hombreNuevo(Hombre hombre) {
        return "/hombre/modificar";
    }

    @PostMapping("/hombre/guardar")
    public String hombreGuardar(Hombre hombre) {
        hombreService.save(hombre);
        return "redirect:/hombre/listado";
    }

    @GetMapping("/hombre/modificar/{CodigoHombre}")
    public String hombreModificar(Hombre hombre,Model model) {
        hombre = hombreService.getHombre(hombre);
        model.addAttribute("hombre",hombre);
        return "/hombre/modificar";
    }

    @GetMapping("/hombre/eliminar/{CodigoHombre}")
    public String hombreEliminar(Hombre hombre) {
        hombreService.delete( hombre);        
        return "redirect:/hombre/listado";
    }  
}
