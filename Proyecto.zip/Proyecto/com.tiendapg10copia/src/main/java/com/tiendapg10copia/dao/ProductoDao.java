
package com.tiendapg10copia.dao;

import com.tiendapg10copia.domain.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Andres
 */
public interface ProductoDao extends JpaRepository<Producto,Long>{} 
    