
package com.tiendapg10copia;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
    
    @Autowired
    private UserDetailsService userDetailsService;
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
       /*auth.inMemoryAuthentication()
                .withUser("Juan")
                .password("{noop}123")
                .roles("ADMIN","VENDEDOR","USER").and()
                .withUser("Rebeca")
                .password("{noop}456")
                .roles("VENDEDOR","USER").and()
                .withUser("Pedro")
                .password("{noop}789")
                .roles("USER");*/
        auth.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests().antMatchers("/producto/nuevo", 
                "/producto/guardar", 
                "/producto/modificar/**", 
                "/producto/eliminar/**",
                "/hombre/nuevo", 
                "/hombre/guardar", 
                "/hombre/modificar/**", 
                "/hombre/eliminar/**",
                "/infantil/nuevo", 
                "/infantil/guardar", 
                "/infantil/modificar/**", 
                "/infantil/eliminar/**",
                "/mujer/nuevo", 
                "/mujer/guardar", 
                "/mujer/modificar/**", 
                "/mujer/eliminar/**",
                "/temporada/nuevo", 
                "/temporada/guardar", 
                "/temporada/modificar/**", 
                "/temporada/eliminar/**",
                "/usuario/nuevo", 
                "/usuario/guardar", 
                "/usuario/modificar/**", 
                "/usuario/eliminar/**",
                "/autenticar/nuevo", 
                "/autenticar/guardar", 
                "/autenticar/modificar/**", 
                "/autenticar/eliminar/**",
        "/producto/listado","hombre/listado","mujer/listado","infantil/listado",
                        "/temporada/listado",
                        "/usuario/listado").hasRole("ADMIN")
                .antMatchers("/producto/listado","hombre/listado","mujer/listado","infantil/listado",
                        "/temporada/listado",
                        "/usuario/listado")
                .hasAnyRole("ADMIN", "EMPLEADO")
                .antMatchers("/","/carrito/**","/producto/listado","hombre/listado","mujer/listado","infantil/listado",
                        "/temporada/listado",
                        "/usuario/listado")
                .permitAll()
                .antMatchers("/facturar/carrito/")
                .authenticated()
                .and().formLogin().loginPage("/login")
                .and().exceptionHandling().accessDeniedPage("/errores/403"); 
    }
}
