
package com.tiendapg10copia.service;

import com.tiendapg10copia.dao.InfantilDao;
import com.tiendapg10copia.domain.Infantil;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 *
 * @author Andres
 */

@Service
public class InfantilServiceImpl implements InfantilService {
    
    
     @Autowired
    private InfantilDao infantilDao;
    
    @Override
    @Transactional(readOnly = true)
    public List<Infantil> getInfantiles(boolean activos) {
        return (List<Infantil>)infantilDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Infantil getInfantil(Infantil infantil) {
      return infantilDao.findById(infantil.getCodigoInfantil()).orElse(null);
}

    @Override
    @Transactional
    public void save(Infantil infantil) {
        infantilDao.save(infantil);
    }

    @Override
    @Transactional
    public void delete(Infantil infantil) {
        infantilDao.delete(infantil);
    }   
    
}