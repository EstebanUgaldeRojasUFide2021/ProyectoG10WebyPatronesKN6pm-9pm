
package com.tiendapg10copia.service;

/**
 *
 * @author Andres
 */

import com.tiendapg10copia.domain.Infantil;
import java.util.List;

public interface InfantilService {
    
     //Los métodos para hacer un CRUD de la tabla articulo
    //Create Read Update Delete
    
    public List<Infantil> getInfantiles(boolean activos);
    
    public Infantil getInfantil(Infantil infantil);
    
    public void save(Infantil infantil);
    
    public void delete(Infantil infantil);
    
}