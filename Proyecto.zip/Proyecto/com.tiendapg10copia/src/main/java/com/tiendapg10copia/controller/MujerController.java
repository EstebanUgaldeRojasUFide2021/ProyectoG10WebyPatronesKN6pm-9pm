package com.tiendapg10copia.controller;

import com.tiendapg10copia.domain.Mujer;
import com.tiendapg10copia.service.MujerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author Andres
 */

@Controller
@Slf4j
public class MujerController {
    
      @Autowired
    private MujerService mujerService;
    
    @GetMapping("/mujer/listado")
    public String listado(Model model) 
    {
        var mujeres=mujerService.getMujeres(false);
        
        model.addAttribute("mujeres",mujeres);
        return "/mujer/listado";
    }
    
    @GetMapping("/mujer/nuevo")
    public String mujerNuevo(Mujer mujer) {
        return "/mujer/modificar";
    }

    @PostMapping("/mujer/guardar")
    public String mujerGuardar(Mujer mujer) {
        mujerService.save(mujer);
        return "redirect:/mujer/listado";
    }

    @GetMapping("/mujer/modificar/{CodigoMujer}")
    public String mujerModificar(Mujer mujer,Model model) {
        mujer = mujerService.getMujer(mujer);
        model.addAttribute("mujer",mujer);
        return "/mujer/modificar";
    }

    @GetMapping("/mujer/eliminar/{CodigoMujer}")
    public String mujerEliminar(Mujer mujer) {
        mujerService.delete( mujer);        
        return "redirect:/mujer/listado";
    }  
}
