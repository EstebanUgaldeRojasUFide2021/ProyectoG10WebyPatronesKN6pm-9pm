
package com.tiendapg10copia.service;

import com.tiendapg10copia.dao.AutenticarDao;
import com.tiendapg10copia.domain.Rol;
import com.tiendapg10copia.domain.Autenticar;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AutenticarServiceImpl implements UserDetailsService {

    @Autowired
    private AutenticarDao autenticarDao;

    @Override
    @Transactional(readOnly=true)
    public UserDetails loadUserByUsername(String username) 
            throws UsernameNotFoundException {
        Autenticar autenticar = autenticarDao.findByUsername(username);
        
        if(autenticar==null){
            throw new UsernameNotFoundException(username);
        }
        
        var roles = new ArrayList<GrantedAuthority>();
        
        for (Rol rol : autenticar.getRoles()){
            roles.add(new SimpleGrantedAuthority(rol.getNombre()));
        }
        return new User(autenticar.getUsername(),autenticar.getPassword(),roles);
    }
    
    
    
    
}
