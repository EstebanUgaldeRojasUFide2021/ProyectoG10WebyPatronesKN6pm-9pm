package com.tiendapg10copia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tiendapg10copiaApplication 
{
	public static void main(String[] args) 
        {
		SpringApplication.run(Tiendapg10copiaApplication.class, args);
	}

}
