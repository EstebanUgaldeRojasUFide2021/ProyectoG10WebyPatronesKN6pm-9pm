/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tiendapg10copia.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Andres
 */

@Data
@Entity
@Table(name = "mujeres")
public class Mujer implements Serializable {

private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="codigo_mujer")
private Long CodigoMujer;
//private Long IdTemporada;
String nombre_mujer;
String descripcion;
String marca_mujer;
String color_mujer;
int cantidad_mujer;
int precio_mujer;

private boolean activo; 

public Mujer(){}

    public Mujer(Long CodigoMujer, String nombre_mujer, String descripcion, String marca_mujer, String color_mujer, int cantidad_mujer, int precio_mujer, boolean activo) {
        this.CodigoMujer = CodigoMujer;
        this.nombre_mujer = nombre_mujer;
        this.descripcion = descripcion;
        this.marca_mujer = marca_mujer;
        this.color_mujer = color_mujer;
        this.cantidad_mujer = cantidad_mujer;
        this.precio_mujer = precio_mujer;
        this.activo = activo;
    }

   }
