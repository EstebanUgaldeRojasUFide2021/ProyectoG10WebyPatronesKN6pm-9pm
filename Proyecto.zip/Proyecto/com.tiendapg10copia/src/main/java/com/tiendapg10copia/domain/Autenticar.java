package com.tiendapg10copia.domain;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
@Entity
@Table(name="autenticar")
public class Autenticar implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_auth")
    private Long idAuth;
    
    @NotEmpty
    String username;
    @NotEmpty
    String password;
    
    @OneToMany
    @JoinColumn(name="id_auth")
    private List<Rol> roles;
}
