/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tiendapg10copia.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Andres
 */

@Data
@Entity
@Table(name = "infantiles")
public class Infantil implements Serializable {

private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="codigo_infantil")
private Long CodigoInfantil;

String nombre_infantil;
String descripcion;
String marca_infantil;
String color_infantil;
int cantidad_infantil;
int precio_infantil;

private boolean activo; 

public Infantil(){}

    public Infantil(Long CodigoInfantil, String nombre_infantil, String descripcion, String marca_infantil, String color_infantil, int cantidad_infantil, int precio_infantil, boolean activo) {
        this.CodigoInfantil = CodigoInfantil;
        this.nombre_infantil = nombre_infantil;
        this.descripcion = descripcion;
        this.marca_infantil = marca_infantil;
        this.color_infantil = color_infantil;
        this.cantidad_infantil = cantidad_infantil;
        this.precio_infantil = precio_infantil;
        this.activo = activo;
    }
    
   }
