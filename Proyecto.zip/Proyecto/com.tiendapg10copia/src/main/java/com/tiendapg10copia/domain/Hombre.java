/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tiendapg10copia.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Andres
 */

@Data
@Entity
@Table(name = "hombres")
public class Hombre implements Serializable {

private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="codigo_hombre")
private Long CodigoHombre;

String nombre_hombre;
String descripcion;
String marca_hombre;
String color_hombre;
int cantidad_hombre;
int precio_hombre;

private boolean activo; 

public Hombre(){
}

    public Hombre(Long CodigoHombre, String nombre_hombre, String descripcion, String marca_hombre, String color_hombre, int cantidad_hombre, int precio_hombre, boolean activo) {
        this.CodigoHombre = CodigoHombre;
        this.nombre_hombre = nombre_hombre;
        this.descripcion = descripcion;
        this.marca_hombre = marca_hombre;
        this.color_hombre = color_hombre;
        this.cantidad_hombre = cantidad_hombre;
        this.precio_hombre = precio_hombre;
        this.activo = activo;
    }
}
