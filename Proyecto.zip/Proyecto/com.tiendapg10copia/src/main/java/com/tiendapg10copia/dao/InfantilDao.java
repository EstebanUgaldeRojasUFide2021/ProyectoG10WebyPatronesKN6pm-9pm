
package com.tiendapg10copia.dao;


import com.tiendapg10copia.domain.Infantil;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Andres
 */
public interface InfantilDao extends JpaRepository<Infantil,Long>{} 
    