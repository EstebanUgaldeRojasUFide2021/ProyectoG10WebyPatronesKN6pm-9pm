
package com.tiendapg10copia.service;

import com.tiendapg10copia.dao.HombreDao;
import com.tiendapg10copia.domain.Hombre;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 *
 * @author Andres
 */

@Service
public class HombreServiceImpl implements HombreService {
    
    
     @Autowired
    private HombreDao hombreDao;
    
    @Override
    @Transactional(readOnly = true)
    public List<Hombre> getHombres(boolean activos) {
        return (List<Hombre>)hombreDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Hombre getHombre(Hombre hombre) {
      return hombreDao.findById(hombre.getCodigoHombre()).orElse(null);
}

    @Override
    @Transactional
    public void save(Hombre hombre) {
        hombreDao.save(hombre);
    }

    @Override
    @Transactional
    public void delete(Hombre hombre) {
        hombreDao.delete(hombre);
    }   
    
}