
package com.tiendapg10copia.service;

import com.tiendapg10copia.dao.MujerDao;
import com.tiendapg10copia.domain.Mujer;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 *
 * @author Andres
 */

@Service
public class MujerServiceImpl implements MujerService {
    
    
     @Autowired
    private MujerDao mujerDao;
    
    @Override
    @Transactional(readOnly = true)
    public List<Mujer> getMujeres(boolean activos) {
        return (List<Mujer>)mujerDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Mujer getMujer(Mujer mujer) {
      return mujerDao.findById(mujer.getCodigoMujer()).orElse(null);
}

    @Override
    @Transactional
    public void save(Mujer mujer) {
        mujerDao.save(mujer);
    }

    @Override
    @Transactional
    public void delete(Mujer mujer) {
        mujerDao.delete(mujer);
    }   
    
}