package com.tiendapg10copia.dao;

import com.tiendapg10copia.domain.Autenticar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutenticarDao extends JpaRepository<Autenticar, Long>{ public Autenticar findByUsername (String username);}
