
package com.tiendapg10copia.dao;

import com.tiendapg10copia.domain.Hombre;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Andres
 */
public interface HombreDao extends JpaRepository<Hombre,Long>{} 
    