
package com.tiendapg10copia.service;

/**
 *
 * @author Andres
 */

import com.tiendapg10copia.domain.Mujer;
import java.util.List;

public interface MujerService {
    
     //Los métodos para hacer un CRUD de la tabla articulo
    //Create Read Update Delete
    
    public List<Mujer> getMujeres(boolean activos);
    
    public Mujer getMujer(Mujer mujer);
    
    public void save(Mujer mujer);
    
    public void delete(Mujer mujer);
    
}